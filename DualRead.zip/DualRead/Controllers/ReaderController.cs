using DualRead.Models;
using DualRead.Services;
using DualRead.Services.Interfaces;
using DualRead.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace DualRead.Controllers;

[Route("Reader")]
public class ReaderController : Controller
{
    private const int MaxTranslationLength = 20000;
    private const string DocxContentType = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";

    private readonly IBookService _bookService;
    private readonly IEpubParsingService _epubParsingService;
    private readonly IPdfParsingService _pdfParsingService;
    private readonly IDocxParsingService _docxParsingService;
    private readonly IReadingProgressService _readingProgressService;
    private readonly IBookmarkService _bookmarkService;
    private readonly ITranslationService _translationService;
    private readonly ITranslationExportService _translationExportService;
    private readonly ICurrentRecoveryKeyAccessor _currentRecoveryKeyAccessor;
    private readonly ISettingsService _settingsService;

    public ReaderController(
        IBookService bookService,
        IEpubParsingService epubParsingService,
        IPdfParsingService pdfParsingService,
        IDocxParsingService docxParsingService,
        IReadingProgressService readingProgressService,
        IBookmarkService bookmarkService,
        ITranslationService translationService,
        ITranslationExportService translationExportService,
        ICurrentRecoveryKeyAccessor currentRecoveryKeyAccessor,
        ISettingsService settingsService)
    {
        _bookService = bookService;
        _epubParsingService = epubParsingService;
        _pdfParsingService = pdfParsingService;
        _docxParsingService = docxParsingService;
        _readingProgressService = readingProgressService;
        _bookmarkService = bookmarkService;
        _translationService = translationService;
        _translationExportService = translationExportService;
        _currentRecoveryKeyAccessor = currentRecoveryKeyAccessor;
        _settingsService = settingsService;
    }

    [HttpGet("{id:guid}")]
    [HttpGet("Index/{id:guid}")]
    public async Task<IActionResult> Index(Guid id)
    {
        var book = await _bookService.GetBookByIdAsync(id);
        if (book is null)
        {
            return NotFound();
        }

        var recoveryKey = await _currentRecoveryKeyAccessor.GetCurrentAsync();
        var isPdf = book.Type == BookType.Pdf;
        var canTranslate = !isPdf && recoveryKey is not null && recoveryKey.Id == book.RecoveryKeyId;

        var chapters = await _bookService.GetChaptersAsync(id);
        var progress = await _readingProgressService.GetByBookIdAsync(id);
        var bookmarks = await _bookmarkService.GetByBookIdAsync(id);

        var bundle = new ReaderBundleViewModel
        {
            BookId = book.Id,
            Title = book.Title,
            Author = book.Author,
            BookType = book.Type,
            Chapters = chapters.Select(c => new ReaderChapterSummary
            {
                Id = c.Id,
                Order = c.Order,
                Title = c.Title
            }).ToList(),
            Bookmarks = bookmarks.Select(ToSummary).ToList(),
            CanTranslate = canTranslate,
            CanSaveSettings = recoveryKey is not null,
            Settings = recoveryKey is null
                ? new SettingsViewModel()
                : SettingsViewModel.From(await _settingsService.GetAsync(recoveryKey.Id)),
            TranslationModeOn = canTranslate && (progress?.TranslationModeOn ?? false),
            IsPdf = isPdf,
            PdfAvailable = isPdf && System.IO.File.Exists(book.EpubFilePath)
        };

        if (isPdf)
        {
            return View(bundle);
        }

        var landingChapter = chapters.FirstOrDefault();
        if (progress?.CurrentChapterId is not null)
        {
            var savedChapter = chapters.FirstOrDefault(c => c.Id == progress.CurrentChapterId);
            if (savedChapter is not null)
            {
                landingChapter = savedChapter;
                bundle.LandingPage = progress.CurrentPage;
            }
        }

        if (landingChapter is not null)
        {
            bundle.LandingChapterId = landingChapter.Id;
            bundle.LandingChapterHtml = await LoadSanitizedChapterHtmlAsync(book, landingChapter);
        }

        return View(bundle);
    }

    [HttpGet("{id:guid}/Pdf")]
    public async Task<IActionResult> Pdf(Guid id)
    {
        var book = await GetOwnedBookAsync(id);
        if (book is null || book.Type != BookType.Pdf || !System.IO.File.Exists(book.EpubFilePath))
        {
            return NotFound();
        }

        return PhysicalFile(book.EpubFilePath, "application/pdf", enableRangeProcessing: true);
    }

    [HttpGet("{id:guid}/Chapter/{chapterId:guid}")]
    public async Task<IActionResult> Chapter(Guid id, Guid chapterId)
    {
        var book = await _bookService.GetBookByIdAsync(id);
        if (book is null)
        {
            return NotFound();
        }

        var chapter = await FindChapterAsync(id, chapterId);
        if (chapter is null)
        {
            return NotFound();
        }

        var html = await LoadSanitizedChapterHtmlAsync(book, chapter);
        return Json(new { title = chapter.Title, html });
    }

    [HttpGet("{id:guid}/Asset")]
    public async Task<IActionResult> Asset(Guid id, [FromQuery] Guid chapterId, [FromQuery] string src)
    {
        var book = await _bookService.GetBookByIdAsync(id);
        if (book is null || book.Type != BookType.Epub)
        {
            return NotFound();
        }

        var chapter = await FindChapterAsync(id, chapterId);
        if (chapter is null)
        {
            return NotFound();
        }

        var asset = await _epubParsingService.GetAssetAsync(book.EpubFilePath, chapter.EpubItemHref, src);
        if (asset is null)
        {
            return NotFound();
        }

        return File(asset.Value.Bytes, asset.Value.ContentType);
    }

    [HttpPost("{id:guid}/Progress")]
    public async Task<IActionResult> SaveProgress(Guid id, [FromBody] SaveProgressDto dto)
    {
        var book = await _bookService.GetBookByIdAsync(id);
        if (book is null)
        {
            return NotFound();
        }

        await _readingProgressService.SaveAsync(id, dto.ChapterId, dto.Page, dto.TranslationModeOn);
        return Ok();
    }

    [HttpGet("{id:guid}/Chapter/{chapterId:guid}/Translations")]
    public async Task<IActionResult> GetTranslations(Guid id, Guid chapterId)
    {
        var book = await GetOwnedBookAsync(id);
        if (book is null)
        {
            return StatusCode(StatusCodes.Status403Forbidden);
        }

        if (await FindChapterAsync(id, chapterId) is null)
        {
            return NotFound();
        }

        var translations = await _translationService.GetByChapterAsync(chapterId);
        return Ok(translations.Select(t => new { paragraphIndex = t.ParagraphIndex, translatedText = t.TranslatedText }));
    }

    [HttpPost("{id:guid}/Chapter/{chapterId:guid}/Translations")]
    public async Task<IActionResult> SaveTranslation(Guid id, Guid chapterId, [FromBody] TranslationSaveDto? dto)
    {
        if (dto is null || dto.ParagraphIndex < 0 || (dto.TranslatedText?.Length ?? 0) > MaxTranslationLength)
        {
            return BadRequest(new { error = "Invalid translation payload." });
        }

        var book = await GetOwnedBookAsync(id);
        if (book is null)
        {
            return StatusCode(StatusCodes.Status403Forbidden);
        }

        if (await FindChapterAsync(id, chapterId) is null)
        {
            return NotFound();
        }

        await _translationService.UpsertAsync(id, chapterId, dto.ParagraphIndex, dto.TranslatedText ?? string.Empty);
        return Ok();
    }

    [HttpGet("{id:guid}/ExportTranslation")]
    public async Task<IActionResult> ExportTranslation(Guid id)
    {
        var recoveryKey = await _currentRecoveryKeyAccessor.GetCurrentAsync();
        if (recoveryKey is null)
        {
            return RedirectToAction("Index", "Home");
        }

        var export = await _translationExportService.ExportTranslationToDocxAsync(id, recoveryKey.Id);
        if (export is null)
        {
            return NotFound();
        }

        return File(export.Value.Bytes, DocxContentType, export.Value.FileName);
    }

    [HttpPost("{id:guid}/Bookmarks")]
    public async Task<IActionResult> AddBookmark(Guid id, [FromBody] CreateBookmarkDto dto)
    {
        var book = await _bookService.GetBookByIdAsync(id);
        if (book is null)
        {
            return NotFound();
        }

        var bookmark = await _bookmarkService.AddAsync(id, dto.ChapterId, dto.Page, dto.PreviewText);
        return Ok(ToSummary(bookmark));
    }

    [HttpDelete("{id:guid}/Bookmarks/{bookmarkId:guid}")]
    public async Task<IActionResult> DeleteBookmark(Guid id, Guid bookmarkId)
    {
        var deleted = await _bookmarkService.DeleteAsync(bookmarkId);
        if (!deleted)
        {
            return NotFound();
        }

        return Ok();
    }

    private async Task<Chapter?> FindChapterAsync(Guid bookId, Guid chapterId)
    {
        var chapters = await _bookService.GetChaptersAsync(bookId);
        return chapters.FirstOrDefault(c => c.Id == chapterId);
    }

    private async Task<Book?> GetOwnedBookAsync(Guid id)
    {
        var recoveryKey = await _currentRecoveryKeyAccessor.GetCurrentAsync();
        if (recoveryKey is null)
        {
            return null;
        }

        var book = await _bookService.GetBookByIdAsync(id);
        return book is not null && book.RecoveryKeyId == recoveryKey.Id ? book : null;
    }

    private static BookmarkSummary ToSummary(Bookmark bookmark)
    {
        return new BookmarkSummary
        {
            Id = bookmark.Id,
            ChapterId = bookmark.ChapterId,
            Page = bookmark.PageNumber,
            PreviewText = bookmark.PreviewText,
            CreatedAtUtc = bookmark.CreatedAtUtc
        };
    }

    private async Task<string> LoadSanitizedChapterHtmlAsync(Book book, Chapter chapter)
    {
        var rawHtml = book.Type switch
        {
            BookType.Epub => await _epubParsingService.GetChapterHtmlAsync(book.EpubFilePath, chapter.EpubItemHref),
            BookType.Pdf => await _pdfParsingService.GetChapterHtmlAsync(book.EpubFilePath, chapter.EpubItemHref),
            BookType.Docx => await _docxParsingService.GetChapterHtmlAsync(book.EpubFilePath, chapter.EpubItemHref),
            _ => string.Empty
        };

        string html;
        if (book.Type == BookType.Pdf)
        {
            html = rawHtml;
        }
        else
        {
            Func<string, string>? resolveAssetUrl = book.Type == BookType.Epub
                ? src => Url.Action("Asset", "Reader", new { id = book.Id, chapterId = chapter.Id, src })!
                : null;

            html = ChapterHtmlSanitizer.ExtractAndSanitize(rawHtml, resolveAssetUrl);
        }

        return ChapterHtmlSanitizer.IndexParagraphs(html);
    }
}